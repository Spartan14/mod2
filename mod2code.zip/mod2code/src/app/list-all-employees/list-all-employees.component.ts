import { Component, OnInit } from '@angular/core';
import employeeData from '../Data/EmployeeDetails.json'
@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
employee=employeeData
  constructor() { }

  ngOnInit() {
  }
delete(i)
{
  this.employee.splice(i,1);
}
}
